import 'package:integration_test/integration_test.dart';
import 'package:integration_test/integration_test_driver_extended.dart';

void main() => integrationDriver();
