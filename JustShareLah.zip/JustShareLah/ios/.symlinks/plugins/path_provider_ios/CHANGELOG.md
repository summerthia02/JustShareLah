## 2.0.9

* Fixes library_private_types_in_public_api, sort_child_properties_last and use_key_in_widget_constructors
  lint warnings.

## 2.0.8

* Switches to a package-internal implementation of the platform interface.

## 2.0.7

* Fixes link in README.

## 2.0.6

* Split from `path_provider` as a federated implementation.
