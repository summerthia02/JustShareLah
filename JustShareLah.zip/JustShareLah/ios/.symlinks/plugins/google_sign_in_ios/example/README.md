# google_sign_in_ios example

Exercises the iOS implementation of `GoogleSignInPlatform`.
