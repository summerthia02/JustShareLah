## 2.1.1

* Fixes library_private_types_in_public_api, sort_child_properties_last and use_key_in_widget_constructors
  lint warnings.

## 2.1.0

* Upgrades to using Pigeon.

## 2.0.10

* Switches to an in-package method channel implementation.

## 2.0.9

* Removes dependency on `meta`.

## 2.0.8

* Split from `shared_preferences` as a federated implementation.
